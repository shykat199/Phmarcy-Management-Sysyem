package pharmacy.com;

import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JSeparator;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class progressbar {

	private JFrame frame;
	private JProgressBar progressBar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		final JFrame frame =new JFrame();
		frame.setBounds(100, 100, 612, 315);
		frame.setUndecorated(true);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	       JPanel panel=new JPanel();
	       panel.setBackground(Color.WHITE);
	       panel.setLayout(null);

	       JProgressBar bar=new JProgressBar();
	       bar.setForeground(Color.GREEN);
	        UIManager.put("ProgressBar.selectionBackground",Color.RED); 

	       //bar.setForeground(Color.WHITE);
	       //bar.setBackground(Color.GREEN);
	       bar.setBounds(137, 283, 320, 21);
	       bar.setMaximum(100);
	       bar.setMinimum(0);
	       bar.setStringPainted(true);
	       panel.add(bar);


	       frame.getContentPane().add(panel);
	       
	       JLabel lblNewLabel = new JLabel("Pharmacy Management System");
	       lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	       lblNewLabel.setForeground(Color.GREEN);
	       lblNewLabel.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 32));
	       lblNewLabel.setBackground(Color.GREEN);
	       lblNewLabel.setBounds(57, 60, 516, 45);
	       panel.add(lblNewLabel);
	       
	       JSeparator separator = new JSeparator();
	       separator.setBackground(Color.GREEN);
	       separator.setBounds(67, 105, 493, 10);
	       panel.add(separator);
	       
	       JPanel x = new JPanel() {
	       	protected void paintComponent(Graphics g) {
	       		super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
	       	}
	       };
	       x.addMouseListener(new MouseAdapter() {
	       	@Override
	       	public void mouseClicked(MouseEvent e) {
	       		System.exit(0);
	       	}
	       });
	       x.setLayout(null);
	       x.setOpaque(false);
	       x.setBackground(Color.WHITE);
	       x.setBounds(555, 11, 47, 45);
	       panel.add(x);
	       
	       JLabel lblNewLabel_1 = new JLabel("X");
	       lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
	       lblNewLabel_1.setForeground(Color.GREEN);
	       lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 22));
	       lblNewLabel_1.setBackground(Color.LIGHT_GRAY);
	       lblNewLabel_1.setBounds(5, 11, 37, 23);
	       x.add(lblNewLabel_1);
	       
	       JPanel x_1 = new JPanel() {
	       	protected void paintComponent(Graphics g) {
	       		super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
	       	}
	       };
	       x_1.addMouseListener(new MouseAdapter() {
	       	@Override
	       	public void mouseClicked(MouseEvent e) {
	       		
				frame.setState(JFrame.ICONIFIED);

	       	}
	       });
	       x_1.setLayout(null);
	       x_1.setOpaque(false);
	       x_1.setBackground(Color.WHITE);
	       x_1.setBounds(505, 11, 47, 45);
	       panel.add(x_1);
	       
	       JLabel lblNewLabel_1_1 = new JLabel("-");
	       lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
	       lblNewLabel_1_1.setForeground(Color.GREEN);
	       lblNewLabel_1_1.setFont(new Font("SansSerif", Font.BOLD, 35));
	       lblNewLabel_1_1.setBackground(Color.LIGHT_GRAY);
	       lblNewLabel_1_1.setBounds(5, 7, 37, 23);
	       x_1.add(lblNewLabel_1_1);
	       
	       
	       ImageIcon imageIcon = new ImageIcon(new ImageIcon(
					"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
							.getImage().getScaledInstance(320, 150, Image.SCALE_DEFAULT));
	       
	       JLabel lblNewLabel_2 = new JLabel("");
	       lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
	       lblNewLabel_2.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
	       lblNewLabel_2.setBounds(137, 116, 320, 140);
	       lblNewLabel_2.setIcon(imageIcon);
	       panel.add(lblNewLabel_2);
	       //frame.pack();
	       frame.setVisible(true);

	       for(int i=0;i<=100;i++){
	           bar.setValue(i);
	           try {
	               Thread.sleep(40);
	           } catch (InterruptedException e) {
	               // TODO Auto-generated catch block
	               e.printStackTrace();
	           }

	       }
	       Log_in log_in=new Log_in();
	       log_in.visible();
	       frame.dispose();
	   }
	}

