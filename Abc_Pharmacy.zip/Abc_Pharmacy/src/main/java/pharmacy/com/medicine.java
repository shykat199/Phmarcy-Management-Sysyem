package pharmacy.com;

import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.RenderingHints;

import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.UIManager;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.toedter.calendar.JDateChooser;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import java.awt.SystemColor;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class medicine {

	private static JFrame frame;
	private JTextField id;
	private JTextField name;
	private JTextField qut;
	private JTextField price;
	private JTable table;
	private JLabel lblNewLabel_4_1_1;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					medicine window = new medicine();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public medicine() throws ClassNotFoundException, SQLException {
		initialize();
		autoId();
		Refresh();
		GetCompany();
	}
	
	
private void autoId() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
		System.out.println("Connection sucessful");
		java.sql.Statement stmtStatement=connection.createStatement();
		ResultSet resultSet=stmtStatement.executeQuery("select Max(id) from medicine");
		resultSet.next();
		String idString= resultSet.getString("Max(id)");
		
		if (idString==null) {
			id.setText("MED0001");
		}
		else {
			long id=Long.parseLong(idString.substring(3,idString.length()));
			id++;
			this.id.setText("MED"+String.format("%04d", id));
			
		}
		

	}


public void Refresh() throws ClassNotFoundException, SQLException {
	
	String dropString="select * from medicine";
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
	PreparedStatement pst=connection.prepareStatement(dropString);
	ResultSet resultSet=pst.executeQuery();
	
	ResultSetMetaData mataData=(ResultSetMetaData) resultSet.getMetaData();
	
	int c=mataData.getColumnCount();
	DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
	tableModel.setRowCount(0);
	
	
	while (resultSet.next()) {
		Vector v2=new Vector();
		
		for (int i = 0; i <=c; i++) {
			v2.add(resultSet.getString("id"));  //column name
			v2.add(resultSet.getString("name"));
			v2.add(resultSet.getString("price"));
			v2.add(resultSet.getString("quantity"));
			v2.add(resultSet.getString("meddate"));
			v2.add(resultSet.getString("medexp"));
			v2.add(resultSet.getString("medcom"));
		}
		
		tableModel.addRow(v2);
	}
	
}

public void GetCompany() throws ClassNotFoundException, SQLException {
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
	String dropString="Select * from company";
	PreparedStatement preparedStatement=connection.prepareStatement(dropString);
	ResultSet resultSet=preparedStatement.executeQuery();
	
	while (resultSet.next()) {
		String companyString=resultSet.getString("Name");
		comboBox.addItem(companyString);
	}
	
}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		
		
		ImageIcon imageIcon = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(320, 150, Image.SCALE_DEFAULT));
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(0, 100, 0));
		panel.setBackground(new Color(0, 100, 0));
		panel.setBounds(0, 0, 755, 648);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(187, 59, 568, 589);
		panel.add(panel_1);
		panel_1.setBackground(Color.WHITE);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Manage Medicine");
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 28));
		lblNewLabel.setForeground(new Color(0, 255, 0));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(203, 11, 239, 38);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("ID");
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2.setBounds(21, 75, 64, 25);
		panel_1.add(lblNewLabel_2);
		
		id = new JTextField();
		id.setBackground(Color.WHITE);
		id.setBounds(117, 75, 116, 25);
		panel_1.add(id);
		id.setColumns(10);
		
		name = new JTextField();
		name.setBackground(Color.WHITE);
		name.setColumns(10);
		name.setBounds(117, 111, 116, 25);
		panel_1.add(name);
		
		JLabel lblNewLabel_2_1 = new JLabel("Medname");
		lblNewLabel_2_1.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_1.setBounds(21, 111, 64, 25);
		panel_1.add(lblNewLabel_2_1);
		
		qut = new JTextField();
		qut.setBackground(Color.WHITE);
		qut.setColumns(10);
		qut.setBounds(117, 199, 116, 25);
		panel_1.add(qut);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Quantity");
		lblNewLabel_2_1_1.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_1_1.setBounds(21, 199, 64, 25);
		panel_1.add(lblNewLabel_2_1_1);
		
		price = new JTextField();
		price.setBackground(Color.WHITE);
		price.setColumns(10);
		price.setBounds(117, 163, 116, 25);
		panel_1.add(price);
		
		JLabel lblNewLabel_2_2 = new JLabel("Price");
		lblNewLabel_2_2.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_2.setBounds(21, 163, 64, 25);
		panel_1.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("FABDATE");
		lblNewLabel_2_3.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_3.setBounds(310, 75, 64, 25);
		panel_1.add(lblNewLabel_2_3);
		
		JLabel exp = new JLabel("EXPDATE");
		exp.setFont(new Font("Serif", Font.BOLD, 14));
		exp.setBounds(310, 111, 64, 25);
		panel_1.add(exp);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Company");
		lblNewLabel_2_2_1.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_2_1.setBounds(310, 199, 64, 25);
		panel_1.add(lblNewLabel_2_2_1);
		
		final JDateChooser fabdate = new JDateChooser();
		fabdate.setDateFormatString("yyyy-MM-dd");
		fabdate.setBounds(406, 75, 116, 25);
		panel_1.add(fabdate);
		
		final JDateChooser expdate = new JDateChooser();
		expdate.setDateFormatString("yyyy-MM-dd");
		expdate.setBounds(406, 111, 116, 25);
		panel_1.add(expdate);
		
		 comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select Iteam"}));
		comboBox.setBackground(Color.WHITE);
		comboBox.setForeground(Color.BLACK);
		comboBox.setBounds(406, 199, 116, 25);
		panel_1.add(comboBox);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 365, 548, 213);
		panel_1.add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane_1.setViewportView(scrollPane);
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				

			}
			@Override
			public void mousePressed(MouseEvent e) {
				
				
				
			}
		});
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id", "Name", "Price", "Quantity", "MedDate", "MedExp", "MedCom"
			}
		));
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		table.setBackground(Color.WHITE);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String idString=id.getText();
				String nameString=name.getText();	
				String pPString=price.getText();
				int price=Integer.valueOf(pPString);
				String qutString=qut.getText();
				int qut=Integer.parseInt(qutString);
				
				
				String companyString=comboBox.getSelectedItem().toString();
				
				SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
				String fabString=dateFormat.format(fabdate.getDate());
				
				SimpleDateFormat dateFormat1=new SimpleDateFormat("yyyy-MM-dd");
				String expString=dateFormat1.format(expdate.getDate());
				
				String dropString="insert into medicine values(?,?,?,?,?,?,?)";
				
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
					
					PreparedStatement preparedStatement=connection.prepareStatement(dropString);
					preparedStatement.setString(1, idString);
					preparedStatement.setString(2, nameString);
					preparedStatement.setInt(3, price);
					preparedStatement.setInt(4, qut);
					preparedStatement.setString(5, fabString);
					preparedStatement.setString(6, expString);
					preparedStatement.setString(7, companyString);
					
					preparedStatement.executeUpdate();
					preparedStatement.close();
					
					JOptionPane.showMessageDialog(frame, "Sucessfully Updated", "Medicine Addedd....",
							JOptionPane.INFORMATION_MESSAGE);
					
					id.setText("");
					name.setText("");
					medicine.this.price.setText("");
					medicine.this.qut.setText("");
					fabdate.setDate(null);
					expdate.setDate(null);
					comboBox.setSelectedIndex(0);

					
					autoId();
					Refresh();

				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnAdd.setFont(new Font("Serif", Font.BOLD, 15));
		btnAdd.setBackground(Color.GREEN);
		btnAdd.setBounds(117, 265, 99, 31);
		panel_1.add(btnAdd);
		
		JButton btndLT = new JButton("DELETE");
		btndLT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
					
					DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
					String dropString="delete from medicine where  id=?";
					int row=table.getSelectedRow();
					String nameString=(String) tableModel.getValueAt(row, 0).toString();
					PreparedStatement pStatement=connection.prepareStatement(dropString);
					pStatement.setString(1, nameString);
					JOptionPane.showMessageDialog(frame, "Sucessfully Deleted", "Medicine Deleated....",JOptionPane.INFORMATION_MESSAGE);
					pStatement.executeUpdate();
					System.out.println("Deleat sucessfull...");
					pStatement.close();
					
					java.sql.Statement stmtStatement=connection.createStatement();
					ResultSet resultSet=stmtStatement.executeQuery("select Max(id) from medicine");
					resultSet.next();
					String idString= resultSet.getString("Max(id)");
					
					if (idString==null) {
						id.setText("MED0001");
					}
					else {
						long id=Long.parseLong(idString.substring(3,idString.length()));
						id++;
						medicine.this.id.setText("MED"+String.format("%04d", id));
						
					}
					
					 Refresh();
					
					
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				
			}
			
		});
		btndLT.setFont(new Font("Serif", Font.BOLD, 15));
		btndLT.setBackground(Color.GREEN);
		btndLT.setBounds(275, 265, 99, 31);
		panel_1.add(btndLT);
		
		JButton btnEdit = new JButton("EDIT");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
				int index=table.getSelectedRow();
				
				id.setText(tableModel.getValueAt(index, 0).toString());
				name.setText(tableModel.getValueAt(index, 1).toString());
				price.setText(tableModel.getValueAt(index, 2).toString());
				qut.setText(tableModel.getValueAt(index, 3).toString());
				
				try {
					java.util.Date dateFormat=new SimpleDateFormat("yyyy-MM-dd").parse((String) tableModel.getValueAt(index, 4));
					fabdate.setDate(dateFormat);
					
					java.util.Date dateFormat1=new SimpleDateFormat("yyyy-MM-dd").parse((String) tableModel.getValueAt(index, 5));
					expdate.setDate(dateFormat1);

				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				comboBox.setSelectedItem(tableModel.getValueAt(index, 6).toString());
			}
		});
		btnEdit.setFont(new Font("Serif", Font.BOLD, 15));
		btnEdit.setBackground(Color.GREEN);
		btnEdit.setBounds(423, 265, 99, 31);
		panel_1.add(btnEdit);
		
		JLabel lblMedicineList = new JLabel("Medicine List");
		lblMedicineList.setHorizontalAlignment(SwingConstants.CENTER);
		lblMedicineList.setForeground(SystemColor.textHighlight);
		lblMedicineList.setFont(new Font("Serif", Font.BOLD, 28));
		lblMedicineList.setBounds(176, 316, 239, 38);
		panel_1.add(lblMedicineList);
		
		
		
		ImageIcon imageIcon1 = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(320, 150, Image.SCALE_DEFAULT));
		

		JPanel x = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
			}
		};
		x.setBounds(698, 11, 47, 37);
		panel.add(x);
		x.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				System.exit(0);
			}
		});
		x.setBackground(Color.WHITE);
		x.setOpaque(false);
		x.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("X");
		lblNewLabel_1.setForeground(Color.green);
		lblNewLabel_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 22));
		lblNewLabel_1.setBounds(5, 7, 37, 23);
		x.add(lblNewLabel_1);
		
		JPanel x_1 = new JPanel() {
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
			}
		};
		x_1.setBounds(648, 11, 47, 37);
		panel.add(x_1);
		x_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.setState(JFrame.ICONIFIED);
			}
		});
		x_1.setLayout(null);
		x_1.setOpaque(false);
		x_1.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_1_1 = new JLabel("-");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.green);
		lblNewLabel_1_1.setFont(new Font("SansSerif", Font.BOLD, 35));
		lblNewLabel_1_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1_1.setBounds(5, 4, 37, 23);
		x_1.add(lblNewLabel_1_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		panel_2.setBackground(Color.WHITE);
		panel_2.setForeground(Color.GREEN);
		panel_2.setBounds(10, 171, 168, 30);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Company");
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hide();
				try {
					Compony compony=new Compony();
					compony.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		lblNewLabel_4.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(0, 2, 168, 25);
		panel_2.add(lblNewLabel_4);
		
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBackground(Color.WHITE);
		panel_2_1.setForeground(Color.GREEN);
		panel_2_1.setBounds(10, 212, 167, 30);
		panel.add(panel_2_1);
		panel_2_1.setLayout(null);
		
		JLabel lblNewLabel_4_1 = new JLabel("Agents");
		lblNewLabel_4_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hide();
				try {
					agent agent=new agent();
					agent.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		lblNewLabel_4_1.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setBounds(0, 2, 167, 25);
		panel_2_1.add(lblNewLabel_4_1);
		
		JPanel panel_2_1_1 = new JPanel();
		panel_2_1_1.setBackground(Color.WHITE);
		panel_2_1_1.setForeground(Color.GREEN);
		panel_2_1_1.setBounds(10, 294, 167, 30);
		panel.add(panel_2_1_1);
		panel_2_1_1.setLayout(null);
		
		JLabel lblNewLabel_4_2 = new JLabel("Selling");
		lblNewLabel_4_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hide();
				try {
					selling selling=new selling();
					selling.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		lblNewLabel_4_2.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2.setBounds(0, 2, 167, 25);
		panel_2_1_1.add(lblNewLabel_4_2);
		
		
		
		
		ImageIcon imageIcon11 = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(167, 122, Image.SCALE_DEFAULT));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(10, 11, 167, 122);
		lblNewLabel_3.setIcon(imageIcon11);
		lblNewLabel_3.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.white));
		panel.add(lblNewLabel_3);
		
		JPanel panel_2_1_2 = new JPanel();
		panel_2_1_2.setLayout(null);
		panel_2_1_2.setForeground(Color.GREEN);
		panel_2_1_2.setBackground(Color.WHITE);
		panel_2_1_2.setBounds(10, 253, 167, 30);
		panel.add(panel_2_1_2);
		
	    lblNewLabel_4_1_1 = new JLabel("Medicine");
		lblNewLabel_4_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_1_1.setBounds(0, 2, 167, 25);
		panel_2_1_2.add(lblNewLabel_4_1_1);
		
		//panel_3.setIcon(imageIcon2);


		//frame.getContentPane().add(panel);
		frame.setBounds(100, 100, 755, 648);
		frame.setUndecorated(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	protected static void hide() {
		frame.hide();
	}
	public  void visible() {
		frame.setVisible(true);
		lblNewLabel_4_1_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_4_1_1.setForeground(Color.blue);
		lblNewLabel_4_1_1.setOpaque(true);
	}
}
