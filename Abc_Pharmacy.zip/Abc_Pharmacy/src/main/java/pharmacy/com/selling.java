package pharmacy.com;

import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.RenderingHints;

import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.UIManager;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.toedter.calendar.JDateChooser;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import java.awt.SystemColor;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

public class selling {

	private static JFrame frame;
	private JTextField id;
	private JTextField name;
	private JTextField qut;
	private JLabel lblNewLabel_4_1_1;
	private JLabel lblNewLabel_4_2;
	private JTable table_1;
	private JTextArea txtrabcPharmacy;
	private int price;
	private int i = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					selling window = new selling();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public selling() throws ClassNotFoundException, SQLException {
		initialize();
		//autoId();
		Refresh();
		//GetCompany();
	}
	
	public void Refresh() throws ClassNotFoundException, SQLException {

		String dropString = "select * from medicine";

		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy", "root", "root");
		PreparedStatement pst = connection.prepareStatement(dropString);
		ResultSet resultSet = pst.executeQuery();

		ResultSetMetaData mataData = (ResultSetMetaData) resultSet.getMetaData();

		int c = mataData.getColumnCount();
		DefaultTableModel tableModel = (DefaultTableModel) table_1.getModel();
		tableModel.setRowCount(0);

		while (resultSet.next()) {
			Vector v2 = new Vector();

			for (int i = 0; i <= c; i++) {
				v2.add(resultSet.getString("id")); // column name
				v2.add(resultSet.getString("name"));
				v2.add(resultSet.getString("price"));
				v2.add(resultSet.getString("quantity"));
				v2.add(resultSet.getString("meddate"));
				v2.add(resultSet.getString("medexp"));
				v2.add(resultSet.getString("medcom"));
			}

			tableModel.addRow(v2);
		}

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		
		
		ImageIcon imageIcon = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(320, 150, Image.SCALE_DEFAULT));
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(0, 100, 0));
		panel.setBackground(new Color(0, 100, 0));
		panel.setBounds(0, 0, 865, 696);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(187, 59, 678, 637);
		panel.add(panel_1);
		panel_1.setBackground(Color.WHITE);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("BillID");
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD, 16));
		lblNewLabel_2.setBounds(21, 107, 64, 25);
		panel_1.add(lblNewLabel_2);
		
		id = new JTextField();
		id.setBackground(Color.WHITE);
		id.setBounds(117, 107, 116, 25);
		panel_1.add(id);
		id.setColumns(10);
		
		name = new JTextField();
		name.setBackground(Color.WHITE);
		name.setColumns(10);
		name.setBounds(117, 165, 116, 25);
		panel_1.add(name);
		
		JLabel lblNewLabel_2_1 = new JLabel("Medname");
		lblNewLabel_2_1.setFont(new Font("Serif", Font.BOLD, 16));
		lblNewLabel_2_1.setBounds(21, 165, 86, 25);
		panel_1.add(lblNewLabel_2_1);
		
		qut = new JTextField();
		qut.setBackground(Color.WHITE);
		qut.setColumns(10);
		qut.setBounds(117, 215, 116, 25);
		panel_1.add(qut);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Quantity");
		lblNewLabel_2_1_1.setFont(new Font("Serif", Font.BOLD, 16));
		lblNewLabel_2_1_1.setBounds(21, 215, 64, 25);
		panel_1.add(lblNewLabel_2_1_1);

		/*JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(243, 103, 383, 251);
		//scrollPane.setColumnHeaderView(scrollPane);	
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id", "Name", "Price", "Quantity", "MedDate", "MedExp", "MedCom"
			}
		));
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		table.setBackground(Color.WHITE);*/
			 
		JButton btnAdd = new JButton("ADD To Bill");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (name.getText().isEmpty() || qut.getText().isEmpty()) {
					JOptionPane.showMessageDialog(frame, "", "Field is empty", JOptionPane.INFORMATION_MESSAGE);
				} else {
					i++;
					if (i == 1) {
						txtrabcPharmacy.setText("         \t*******************ABC Pharmacy*******************\n"
								+ "\t ID       MEDICINE       QTY       PRICE         TOTAL \n\t" + " " + i
								+ "          " + name.getText() + "           " + qut.getText() + "           " + price
								+ "       " + "        " + Integer.valueOf(qut.getText()) * price + "\n");
					} else {
						txtrabcPharmacy.setText(txtrabcPharmacy.getText() + "                              " + i
								+ "          " + name.getText() + "           " + qut.getText() + "           " + price
								+ "       " + "        " + Integer.valueOf(qut.getText()) * price + "\n");
					}

				}

			}
		});
		btnAdd.setFont(new Font("Dialog", Font.BOLD, 18));
		btnAdd.setBackground(Color.GREEN);
		btnAdd.setBounds(21, 276, 212, 31);
		panel_1.add(btnAdd);
		
		JButton btnEdit = new JButton("EDIT");
		btnEdit.setFont(new Font("Dialog", Font.BOLD, 18));
		btnEdit.setBackground(Color.GREEN);
		btnEdit.setBounds(21, 338, 212, 31);
		panel_1.add(btnEdit);
		
		JLabel lblMedicineList = new JLabel("Medicine List");
		lblMedicineList.setHorizontalAlignment(SwingConstants.CENTER);
		lblMedicineList.setForeground(SystemColor.textHighlight);
		lblMedicineList.setFont(new Font("Serif", Font.BOLD, 22));
		lblMedicineList.setBounds(316, 65, 239, 38);
		panel_1.add(lblMedicineList);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					txtrabcPharmacy.print();
				} catch (PrinterException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnPrint.setFont(new Font("Dialog", Font.BOLD, 18));
		btnPrint.setBackground(Color.GREEN);
		btnPrint.setBounds(21, 484, 212, 31);
		panel_1.add(btnPrint);
		
		JLabel lblBill = new JLabel("BILL");
		lblBill.setHorizontalAlignment(SwingConstants.CENTER);
		lblBill.setForeground(SystemColor.textHighlight);
		lblBill.setFont(new Font("Serif", Font.BOLD, 22));
		lblBill.setBounds(316, 380, 239, 38);
		panel_1.add(lblBill);
		
		JLabel lblBilling = new JLabel("Billing");
		lblBilling.setHorizontalAlignment(SwingConstants.CENTER);
		lblBilling.setForeground(SystemColor.textHighlight);
		lblBilling.setFont(new Font("Serif", Font.BOLD, 32));
		lblBilling.setBounds(180, 11, 239, 38);
		panel_1.add(lblBilling);
		
		JScrollPane scrollPane = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				DefaultTableModel tableModel=(DefaultTableModel) table_1.getModel();
				int row=table_1.getSelectedRow();
				
				name.setText(tableModel.getValueAt(row, 1).toString());
				price = Integer.valueOf(tableModel.getValueAt(row, 2).toString());
			}
		});
		scrollPane.setBounds(243, 107, 425, 262);
		panel_1.add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "Id", "Name", "Price", "Quantity", "MedDate", "MedExp", "MedCom" }));
		table_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		table_1.setBackground(Color.WHITE);
		
		JScrollPane scrollPane_1 = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane_1.setBounds(243, 422, 425, 204);
		panel_1.add(scrollPane_1);
		
		 txtrabcPharmacy = new JTextArea();
		txtrabcPharmacy.setForeground(Color.BLACK);
		txtrabcPharmacy.setText("         \t*******************ABC Pharmacy*******************");
		txtrabcPharmacy.setBackground(Color.WHITE);
		scrollPane_1.setViewportView(txtrabcPharmacy);
		
		
		
		ImageIcon imageIcon1 = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(320, 150, Image.SCALE_DEFAULT));
		

		JPanel x = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
			}
		};
		x.setBounds(808, 11, 47, 37);
		panel.add(x);
		x.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				System.exit(0);
			}
		});
		x.setBackground(Color.WHITE);
		x.setOpaque(false);
		x.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("X");
		lblNewLabel_1.setForeground(Color.green);
		lblNewLabel_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 22));
		lblNewLabel_1.setBounds(5, 7, 37, 23);
		x.add(lblNewLabel_1);
		
		JPanel x_1 = new JPanel() {
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
			}
		};
		x_1.setBounds(758, 11, 47, 37);
		panel.add(x_1);
		x_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.setState(JFrame.ICONIFIED);
			}
		});
		x_1.setLayout(null);
		x_1.setOpaque(false);
		x_1.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_1_1 = new JLabel("-");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.green);
		lblNewLabel_1_1.setFont(new Font("SansSerif", Font.BOLD, 35));
		lblNewLabel_1_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1_1.setBounds(5, 4, 37, 23);
		x_1.add(lblNewLabel_1_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		panel_2.setBackground(Color.WHITE);
		panel_2.setForeground(Color.GREEN);
		panel_2.setBounds(10, 171, 168, 30);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Company");
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hide();
				try {
					Compony compony=new Compony();
					compony.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		lblNewLabel_4.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(0, 2, 168, 25);
		panel_2.add(lblNewLabel_4);
		
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBackground(Color.WHITE);
		panel_2_1.setForeground(Color.GREEN);
		panel_2_1.setBounds(10, 212, 167, 30);
		panel.add(panel_2_1);
		panel_2_1.setLayout(null);
		
		JLabel lblNewLabel_4_1 = new JLabel("Agents");
		lblNewLabel_4_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hide();
				try {
					agent agent=new agent();
					agent.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		lblNewLabel_4_1.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setBounds(0, 2, 167, 25);
		panel_2_1.add(lblNewLabel_4_1);
		
		JPanel panel_2_1_1 = new JPanel();
		panel_2_1_1.setBackground(Color.WHITE);
		panel_2_1_1.setForeground(Color.GREEN);
		panel_2_1_1.setBounds(10, 294, 167, 30);
		panel.add(panel_2_1_1);
		panel_2_1_1.setLayout(null);
		
		 lblNewLabel_4_2 = new JLabel("Selling");
		lblNewLabel_4_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		lblNewLabel_4_2.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2.setBounds(0, 2, 167, 25);
		panel_2_1_1.add(lblNewLabel_4_2);
		
		
		
		
		ImageIcon imageIcon11 = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(167, 122, Image.SCALE_DEFAULT));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(10, 11, 167, 122);
		lblNewLabel_3.setIcon(imageIcon11);
		lblNewLabel_3.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
		panel.add(lblNewLabel_3);
		
		JPanel panel_2_1_2 = new JPanel();
		panel_2_1_2.setLayout(null);
		panel_2_1_2.setForeground(Color.GREEN);
		panel_2_1_2.setBackground(Color.WHITE);
		panel_2_1_2.setBounds(10, 253, 167, 30);
		panel.add(panel_2_1_2);
		
	    lblNewLabel_4_1_1 = new JLabel("Medicine");
	    lblNewLabel_4_1_1.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
	    		hide();
	    		try {
					medicine medicine=new medicine();
					medicine.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	    		
	    	}
	    });
		lblNewLabel_4_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_1_1.setBounds(0, 2, 167, 25);
		panel_2_1_2.add(lblNewLabel_4_1_1);
		
		//panel_3.setIcon(imageIcon2);


		//frame.getContentPane().add(panel);
		frame.setBounds(100, 100, 865, 696);
		frame.setUndecorated(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	protected static void hide() {
		frame.hide();
	}
	public  void visible() {
		frame.setVisible(true);
		lblNewLabel_4_2.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_4_2.setForeground(Color.blue);
		lblNewLabel_4_2.setOpaque(true);
	}
}
