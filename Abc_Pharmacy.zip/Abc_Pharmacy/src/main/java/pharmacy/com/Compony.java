package pharmacy.com;

import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.RenderingHints;

import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.UIManager;

import com.mysql.cj.jdbc.Driver;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.toedter.calendar.JDateChooser;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import java.awt.SystemColor;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class Compony {

	private static JFrame frame;
	private JTextField id;
	private JTextField name;
	private JTextField exp;
	private JTextField phone;
	private JTable table;
	private JTextArea add;
	private JLabel lblNewLabel_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Compony window = new Compony();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public Compony() throws ClassNotFoundException, SQLException {
		initialize();
		Refresh();
		AutoId();
	}
	
	public void Refresh() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
		PreparedStatement preparedStatement=connection.prepareStatement("select * from company");
		ResultSet resultSet=preparedStatement.executeQuery();
		
		ResultSetMetaData metaData=(ResultSetMetaData) resultSet.getMetaData();
		int c=metaData.getColumnCount();
		
		DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
		tableModel.setRowCount(0);
		
		
		while (resultSet.next()) {
			
			Vector vector=new Vector();
			for (int i = 0; i < c; i++) {
				vector.add(resultSet.getString("Id"));
				vector.add(resultSet.getString("Name"));
				vector.add(resultSet.getString("Experience"));
				vector.add(resultSet.getString("Phone"));
				vector.add(resultSet.getString("Address"));

			}
			
			tableModel.addRow(vector);
			
		}	
		
	}
	
	public void AutoId() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
		System.out.println("Connection sucessful");
		java.sql.Statement stmtStatement=connection.createStatement();
		ResultSet resultSet=stmtStatement.executeQuery("select Max(Id) from company");
		 while(resultSet.next()) {
		String idString= resultSet.getString("Max(Id)");
		
		if (idString==null) {
			id.setText("COM0001");
		}
		else {
			long id=Long.parseLong(idString.substring(3,idString.length()));
			id++;
			this.id.setText("COM"+String.format("%04d", id));
			
		}
		 }

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		
		
		ImageIcon imageIcon = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(320, 150, Image.SCALE_DEFAULT));
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(0, 100, 0));
		panel.setBackground(new Color(0, 100, 0));
		panel.setBounds(0, 0, 755, 648);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(187, 59, 568, 589);
		panel.add(panel_1);
		panel_1.setBackground(Color.WHITE);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Manage Company");
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 28));
		lblNewLabel.setForeground(new Color(0, 255, 0));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(203, 11, 239, 38);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("ID");
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2.setBounds(21, 75, 64, 25);
		panel_1.add(lblNewLabel_2);
		
		id = new JTextField();
		id.setBackground(Color.WHITE);
		id.setBounds(117, 75, 116, 25);
		panel_1.add(id);
		id.setColumns(10);
		
		name = new JTextField();
		name.setBackground(Color.WHITE);
		name.setColumns(10);
		name.setBounds(117, 132, 116, 25);
		panel_1.add(name);
		
		JLabel lblNewLabel_2_1 = new JLabel("Name");
		lblNewLabel_2_1.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_1.setBounds(21, 132, 64, 25);
		panel_1.add(lblNewLabel_2_1);
		
		exp = new JTextField();
		exp.setBackground(Color.WHITE);
		exp.setColumns(10);
		exp.setBounds(117, 185, 116, 25);
		panel_1.add(exp);
		
		JLabel lblNewLabel_2_2 = new JLabel("Experience");
		lblNewLabel_2_2.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_2.setBounds(21, 185, 86, 25);
		panel_1.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_1_2 = new JLabel("Phone");
		lblNewLabel_2_1_2.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_1_2.setBounds(310, 75, 64, 25);
		panel_1.add(lblNewLabel_2_1_2);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
					PreparedStatement preparedStatement=connection.prepareStatement("insert into company values(?,?,?,?,?)");
					preparedStatement.setString(1, id.getText());
					preparedStatement.setString(2, name.getText());
					preparedStatement.setString(3, exp.getText().toString());
					preparedStatement.setString(4, phone.getText().toString());
					preparedStatement.setString(5, add.getText());
					
					preparedStatement.executeUpdate();
					preparedStatement.close();
						
					
					JOptionPane.showMessageDialog(frame, "Sucessfully Updated", "Company Addedd....",
							JOptionPane.INFORMATION_MESSAGE);
					
					//id.setText("");
					name.setText("");
					exp.setText("");
					phone.setText("");
					add.setText("");
					
					Refresh();
					AutoId();
					
					
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnAdd.setForeground(new Color(255, 255, 255));
		btnAdd.setFont(new Font("Serif", Font.BOLD, 15));
		btnAdd.setBackground(Color.GREEN);
		//btnAdd.setBorder(new RoundedBorder(60));
		btnAdd.setBounds(117, 262, 99, 31);
		panel_1.add(btnAdd);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String idString=id.getText();
				String nameString=name.getText();
			    String  expString=exp.getText();
			    int exp=Integer.valueOf(expString);
			    String  phoneString=phone.getText();
			    int phone=Integer.valueOf(phoneString);
			    String addString=add.getText();
			    
				String dropString="update company set Name=?, Experience=?,Phone=?,Address=? Where id=?";
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
					PreparedStatement preparedStatement=connection.prepareStatement(dropString);
					
					preparedStatement.setString(1, nameString);
					preparedStatement.setInt(2,exp);
					preparedStatement.setInt(3,phone);
					preparedStatement.setString(4, addString);
					preparedStatement.setString(5, idString);
					
					preparedStatement.executeUpdate();
					preparedStatement.close();
					JOptionPane.showMessageDialog(frame, "Sucessfully Updated", "Company Updated....",
							JOptionPane.INFORMATION_MESSAGE);

					
					Refresh();
					AutoId();
					
					
					
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnUpdate.setForeground(new Color(255, 255, 255));
		btnUpdate.setFont(new Font("Serif", Font.BOLD, 15));
		btnUpdate.setBackground(Color.GREEN);
		btnUpdate.setBounds(275, 262, 99, 31);
		panel_1.add(btnUpdate);
		
		JButton btnDelet = new JButton("DELETE");
		btnDelet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
					
					DefaultTableModel tableModel=(DefaultTableModel)table.getModel();
					int row=table.getSelectedRow();
					String nameString=(String) tableModel.getValueAt(row, 0);
					
					PreparedStatement preparedStatement=connection.prepareStatement("delete from company where Id=?");
					preparedStatement.setString(1, nameString);
					JOptionPane.showMessageDialog(frame, "Sucessfully Deleted", "Company Deleated....",
							JOptionPane.INFORMATION_MESSAGE);	
					
					preparedStatement.executeUpdate();
					preparedStatement.close();
					
					Refresh();
					AutoId();
							
							
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnDelet.setForeground(new Color(255, 255, 255));
		btnDelet.setFont(new Font("Serif", Font.BOLD, 15));
		btnDelet.setBackground(Color.GREEN);
		btnDelet.setBounds(421, 262, 99, 31);
		panel_1.add(btnDelet);
		
		JLabel lblMedicineList = new JLabel("Company List");
		lblMedicineList.setHorizontalAlignment(SwingConstants.CENTER);
		lblMedicineList.setForeground(SystemColor.textHighlight);
		lblMedicineList.setFont(new Font("Serif", Font.BOLD, 28));
		lblMedicineList.setBounds(176, 316, 239, 38);
		panel_1.add(lblMedicineList);
		
		phone = new JTextField();
		phone.setColumns(10);
		phone.setBackground(Color.WHITE);
		phone.setBounds(375, 75, 147, 25);
		panel_1.add(phone);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if (e.getClickCount() == 2 && table.getSelectedRow() != -1) {
					
					DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
					int row=table.getSelectedRow();
					
					id.setText(tableModel.getValueAt(row, 0).toString());
					name.setText(tableModel.getValueAt(row, 1).toString());
					exp.setText(tableModel.getValueAt(row, 2).toString());
					phone.setText(tableModel.getValueAt(row, 3).toString());
					add.setText(tableModel.getValueAt(row, 4).toString());
					
				}

			}
		});
		scrollPane.setBounds(21, 379, 520, 199);
		panel_1.add(scrollPane);
		
		table = new JTable();
		//table.setForeground(Color.green);
		table.setSelectionBackground(Color.green);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CompId", "CompName", "CompExp", "CompPhone", "CompAd"
			}
		));
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel_2_1_2_1 = new JLabel("Address");
		lblNewLabel_2_1_2_1.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_1_2_1.setBounds(310, 132, 64, 25);
		panel_1.add(lblNewLabel_2_1_2_1);
		
		JScrollPane scrollPane_1 = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane_1.setBounds(375, 133, 147, 77);
		panel_1.add(scrollPane_1);
		
		add = new JTextArea();
		scrollPane_1.setViewportView(add);
		add.setBackground(Color.WHITE);
		add.setEditable(true);
		add.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.lightGray));
		
		
		
		ImageIcon imageIcon1 = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(320, 150, Image.SCALE_DEFAULT));
		

		JPanel x = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
			}
		};
		x.setBounds(698, 11, 47, 37);
		panel.add(x);
		x.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				System.exit(0);
			}
		});
		x.setBackground(Color.WHITE);
		x.setOpaque(false);
		x.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("X");
		lblNewLabel_1.setForeground(Color.green);
		lblNewLabel_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 22));
		lblNewLabel_1.setBounds(5, 7, 37, 23);
		x.add(lblNewLabel_1);
		
		JPanel x_1 = new JPanel() {
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
			}
		};
		x_1.setBounds(648, 11, 47, 37);
		panel.add(x_1);
		x_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.setState(JFrame.ICONIFIED);
			}
		});
		x_1.setLayout(null);
		x_1.setOpaque(false);
		x_1.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_1_1 = new JLabel("-");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.green);
		lblNewLabel_1_1.setFont(new Font("SansSerif", Font.BOLD, 35));
		lblNewLabel_1_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1_1.setBounds(5, 4, 37, 23);
		x_1.add(lblNewLabel_1_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
			}
		});
		panel_2.setBackground(Color.WHITE);
		panel_2.setForeground(Color.GREEN);
		panel_2.setBounds(10, 171, 168, 30);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		 lblNewLabel_4 = new JLabel("Company");
		 lblNewLabel_4.setBackground(Color.WHITE);
		lblNewLabel_4.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(0, 2, 168, 25);
		panel_2.add(lblNewLabel_4);
		
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBackground(Color.WHITE);
		panel_2_1.setForeground(Color.GREEN);
		panel_2_1.setBounds(10, 212, 167, 30);
		panel.add(panel_2_1);
		panel_2_1.setLayout(null);
		
		JLabel lblNewLabel_4_1 = new JLabel("Agents");
		lblNewLabel_4_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hide();
				try {
					agent agent=new agent();
					agent.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		lblNewLabel_4_1.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setBounds(0, 2, 167, 25);
		panel_2_1.add(lblNewLabel_4_1);
		
		JPanel panel_2_1_1 = new JPanel();
		panel_2_1_1.setBackground(Color.WHITE);
		panel_2_1_1.setForeground(Color.GREEN);
		panel_2_1_1.setBounds(10, 294, 167, 30);
		panel.add(panel_2_1_1);
		panel_2_1_1.setLayout(null);
		
		JLabel lblNewLabel_4_2 = new JLabel("Selling");
		lblNewLabel_4_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hide();
				try {
					selling selling=new selling();
					selling.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		lblNewLabel_4_2.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2.setBounds(0, 2, 167, 25);
		panel_2_1_1.add(lblNewLabel_4_2);
		
		
		
		
		ImageIcon imageIcon11 = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(167, 122, Image.SCALE_DEFAULT));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(10, 11, 167, 122);
		lblNewLabel_3.setIcon(imageIcon11);
		lblNewLabel_3.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.white));
		panel.add(lblNewLabel_3);
		
		JPanel panel_2_1_2 = new JPanel();
		panel_2_1_2.setLayout(null);
		panel_2_1_2.setForeground(Color.GREEN);
		panel_2_1_2.setBackground(Color.WHITE);
		panel_2_1_2.setBounds(10, 253, 167, 30);
		panel.add(panel_2_1_2);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("Medicine");
		lblNewLabel_4_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hide();
				try {
					medicine medicine=new medicine();
					medicine.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		lblNewLabel_4_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_1_1.setBounds(0, 2, 167, 25);
		panel_2_1_2.add(lblNewLabel_4_1_1);
		
		//panel_3.setIcon(imageIcon2);


		//frame.getContentPane().add(panel);
		frame.setBounds(100, 100, 755, 648);
		frame.setUndecorated(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	protected static void hide() {
		frame.hide();
	}
	public  void visible() {
		frame.setVisible(true);
		lblNewLabel_4.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_4.setForeground(Color.blue);
		lblNewLabel_4.setOpaque(true);
	}
}
