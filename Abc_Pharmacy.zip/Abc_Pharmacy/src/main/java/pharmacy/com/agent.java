package pharmacy.com;

import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.RenderingHints;

import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.UIManager;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.toedter.calendar.JDateChooser;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.SystemColor;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class agent {

	private static JFrame frame;
	private static JTextField id;
	private JTextField name;
	private JTextField age;
	private JTable table;
	private JTextField phone;
	private JTextField password;
	private JLabel lblNewLabel_4_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					agent window = new agent();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public agent() throws ClassNotFoundException, SQLException {
		initialize();
		Refresh() ;
		autoId();
	}
	
	
	public void Refresh() throws ClassNotFoundException, SQLException {
		String dropString="select * from agent";
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
		PreparedStatement preparedStatement=connection.prepareStatement(dropString);
		
	   ResultSet resultSet=preparedStatement.executeQuery();
	   
	   ResultSetMetaData mataData=(ResultSetMetaData) resultSet.getMetaData();
	   int c=mataData.getColumnCount();
	   
	   DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
	   tableModel.setRowCount(0);
	   
	   while (resultSet.next()) {
		
		Vector vector=new Vector();
		
		for (int i=0;i<c;i++) {
			vector.add(resultSet.getString("Id"));
			vector.add(resultSet.getString("Name"));
			vector.add(resultSet.getString("Age"));
			vector.add(resultSet.getString("Phone"));
			vector.add(resultSet.getString("Password"));
			vector.add(resultSet.getString("Gender"));

		}
		tableModel.addRow(vector);
		}
	   
	   
	}
	
	public void autoId() throws ClassNotFoundException, SQLException {
		
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
		java.sql.Statement stmtStatement=connection.createStatement();
		ResultSet resultSet=stmtStatement.executeQuery("select Max(Id) from agent");
		resultSet.next();
		String idString=resultSet.getString("Max(Id)");
		if (idString==null) {
			id.setText("Age0001");
		}
		else {
			long id=Long.parseLong(idString.substring(3,idString.length()));
			id++;
			this.id.setText("Age"+String.format("%04d", id));
		}
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		
		
		ImageIcon imageIcon = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(320, 150, Image.SCALE_DEFAULT));
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(0, 100, 0));
		panel.setBackground(new Color(0, 100, 0));
		panel.setBounds(0, 0, 755, 648);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(187, 59, 568, 589);
		panel.add(panel_1);
		panel_1.setBackground(Color.WHITE);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Manage Agent");
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 28));
		lblNewLabel.setForeground(new Color(0, 128, 0));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(203, 11, 239, 38);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("ID");
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2.setBounds(21, 75, 64, 25);
		panel_1.add(lblNewLabel_2);
		
		id = new JTextField();
		id.setBackground(Color.WHITE);
		id.setBounds(117, 75, 116, 25);
		panel_1.add(id);
		id.setColumns(10);
		
		name = new JTextField();
		name.setBackground(Color.WHITE);
		name.setColumns(10);
		name.setBounds(117, 132, 116, 25);
		panel_1.add(name);
		
		JLabel lblNewLabel_2_1 = new JLabel("Name");
		lblNewLabel_2_1.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_1.setBounds(21, 132, 64, 25);
		panel_1.add(lblNewLabel_2_1);
		
		age = new JTextField();
		age.setBackground(Color.WHITE);
		age.setColumns(10);
		age.setBounds(117, 185, 116, 25);
		panel_1.add(age);
		
		JLabel lblNewLabel_2_2 = new JLabel("Age");
		lblNewLabel_2_2.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_2.setBounds(21, 185, 64, 25);
		panel_1.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("Phone");
		lblNewLabel_2_3.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_3.setBounds(310, 75, 64, 25);
		panel_1.add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_1_2 = new JLabel("Password");
		lblNewLabel_2_1_2.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_1_2.setBounds(310, 132, 64, 25);
		panel_1.add(lblNewLabel_2_1_2);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Gender");
		lblNewLabel_2_2_1.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_2_2_1.setBounds(310, 185, 64, 25);
		panel_1.add(lblNewLabel_2_2_1);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select Item","Male", "Female"}));
		comboBox.setBackground(Color.WHITE);
		comboBox.setForeground(Color.BLACK);
		comboBox.setBounds(406, 186, 116, 22);
		panel_1.add(comboBox);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 365, 548, 213);
		panel_1.add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				
				if (e.getClickCount() == 2 && table.getSelectedRow() != -1) {
					// your valueChanged overridden method
					DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
					int row = table.getSelectedRow();

					id.setText(tableModel.getValueAt(row, 0).toString());
					name.setText(tableModel.getValueAt(row, 1).toString());
					age.setText(tableModel.getValueAt(row, 2).toString());
					phone.setText(tableModel.getValueAt(row, 3).toString());
					password.setText(tableModel.getValueAt(row, 4).toString());
					comboBox.setSelectedItem(tableModel.getValueAt(row, 5).toString());
				}
			}
		});
		scrollPane_1.setViewportView(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		//table.setRowSelectionAllowed(false);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"A_Id", "A_Name", "A_Age", "Phone", "Password", "Gender"
			}
		));
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		table.setBackground(Color.WHITE);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String idString=id.getText();
				String nameString=name.getText();
				
				String ageString=age.getText();
				int age=Integer.parseInt(ageString);
				String phoneString=phone.getText();
				int phone=Integer.parseInt(phoneString);
				
				String passwordString=password.getText();
				String genderString=comboBox.getSelectedItem().toString();
				
				
				String  dropString="insert into agent(Id,Name,Age,Phone,Password,Gender) values(?,?,?,?,?,?)";
				try {
					Class.forName("com.mysql.jdbc.Driver");
				Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
				
				PreparedStatement preparedStatement=connection.prepareStatement(dropString);
				
				preparedStatement.setString(1, idString);
				preparedStatement.setString(2, nameString);
				preparedStatement.setInt(3, age);
				preparedStatement.setInt(4, phone);
				preparedStatement.setString(5, passwordString);
				preparedStatement.setString(6, genderString);
				
				preparedStatement.executeUpdate();
				preparedStatement.close();
				
				JOptionPane.showMessageDialog(frame, "Sucessfully Updated", "Agent Addedd....",
						JOptionPane.INFORMATION_MESSAGE);

				id.setText("");
				name.setText("");
				agent.this.age.setText("");
				agent.this.phone.setText("");
				password.setText("");
				comboBox.setSelectedIndex(0);
				
				Refresh();
				autoId();
				
				
				} catch (ClassNotFoundException e1 ) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnAdd.setFont(new Font("Serif", Font.BOLD, 15));
		btnAdd.setBackground(Color.GREEN);
		btnAdd.setBounds(51, 262, 99, 31);
		panel_1.add(btnAdd);
		
		JButton btnEdit = new JButton("EDIT");
		btnEdit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				
			}
		});
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
				int row=table.getSelectedRow();
				
				id.setText(tableModel.getValueAt(row, 0).toString());
				name.setText(tableModel.getValueAt(row, 1).toString());
				age.setText(tableModel.getValueAt(row, 2).toString());
				phone.setText(tableModel.getValueAt(row, 3).toString());
				password.setText(tableModel.getValueAt(row, 4).toString());
				comboBox.setSelectedItem(tableModel.getValueAt(row, 5).toString());
				
			}
		});
		btnEdit.setFont(new Font("Serif", Font.BOLD, 15));
		btnEdit.setBackground(Color.GREEN);
		btnEdit.setBounds(179, 262, 99, 31);
		panel_1.add(btnEdit);
		
		JButton btnDelet = new JButton("DELETE");
		btnDelet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String dropString="delete from agent where Id=?";
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc_pharmacy","root","root");
					DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
					int row=table.getSelectedRow();
					String nameString=tableModel.getValueAt(row, 0).toString();
					PreparedStatement preparedStatement=connection.prepareStatement(dropString);
					preparedStatement.setString(1, nameString);
					JOptionPane.showMessageDialog(frame, "Sucessfully Deleted", "Agent Deleated....",
							JOptionPane.INFORMATION_MESSAGE);
					preparedStatement.executeUpdate();
					System.out.println("Deleat sucessfull...");
					preparedStatement.close();
					Refresh();
					
					/*
					 * 
					 * Decrease the  id number after deleting
					 * 
					*/
					java.sql.Statement stmtStatement=connection.createStatement();
					ResultSet resultSet=stmtStatement.executeQuery("select Max(Id) from agent");
					resultSet.next();
					String idString=resultSet.getString("Max(Id)");
					if (idString==null) {
						id.setText("Age0001");
					}
					else {
						long id=Long.parseLong(idString.substring(3,idString.length()));
						id++;
						agent.id.setText("Age"+String.format("%04d", id));
					}
					
					
					

				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnDelet.setFont(new Font("Serif", Font.BOLD, 15));
		btnDelet.setBackground(Color.GREEN);
		btnDelet.setBounds(310, 262, 99, 31);
		panel_1.add(btnDelet);
		
		JLabel lblMedicineList = new JLabel("Agent List");
		lblMedicineList.setHorizontalAlignment(SwingConstants.CENTER);
		lblMedicineList.setForeground(SystemColor.textHighlight);
		lblMedicineList.setFont(new Font("Serif", Font.BOLD, 28));
		lblMedicineList.setBounds(176, 316, 239, 38);
		panel_1.add(lblMedicineList);
		
		phone = new JTextField();
		phone.setColumns(10);
		phone.setBackground(Color.WHITE);
		phone.setBounds(406, 75, 116, 25);
		panel_1.add(phone);
		
		password = new JTextField();
		password.setColumns(10);
		password.setBackground(Color.WHITE);
		password.setBounds(406, 132, 116, 25);
		panel_1.add(password);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//id.setText("");
				name.setText("");
				age.setText("");
				phone.setText("");
				password.setText("");
				comboBox.setSelectedIndex(0);

			}
		});
		btnClear.setFont(new Font("Serif", Font.BOLD, 15));
		btnClear.setBackground(Color.GREEN);
		btnClear.setBounds(436, 262, 99, 31);
		panel_1.add(btnClear);
		
		
		
		ImageIcon imageIcon1 = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(320, 150, Image.SCALE_DEFAULT));
		

		JPanel x = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
			}
		};
		x.setBounds(698, 11, 47, 37);
		panel.add(x);
		x.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				System.exit(0);
			}
		});
		x.setBackground(Color.WHITE);
		x.setOpaque(false);
		x.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("X");
		lblNewLabel_1.setForeground(Color.green);
		lblNewLabel_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 22));
		lblNewLabel_1.setBounds(5, 7, 37, 23);
		x.add(lblNewLabel_1);
		
		JPanel x_1 = new JPanel() {
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
			}
		};
		x_1.setBounds(648, 11, 47, 37);
		panel.add(x_1);
		x_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.setState(JFrame.ICONIFIED);
			}
		});
		x_1.setLayout(null);
		x_1.setOpaque(false);
		x_1.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_1_1 = new JLabel("-");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.green);
		lblNewLabel_1_1.setFont(new Font("SansSerif", Font.BOLD, 35));
		lblNewLabel_1_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1_1.setBounds(5, 4, 37, 23);
		x_1.add(lblNewLabel_1_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panel_2.setForeground(Color.GREEN);
		panel_2.setBounds(10, 171, 168, 30);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Company");
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hide();
				
				try {
					Compony company=new Compony();
					company.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		lblNewLabel_4.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(0, 2, 168, 25);
		panel_2.add(lblNewLabel_4);
		
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBackground(Color.WHITE);
		panel_2_1.setForeground(Color.GREEN);
		panel_2_1.setBounds(10, 212, 167, 30);
		panel.add(panel_2_1);
		panel_2_1.setLayout(null);
		
		 lblNewLabel_4_1 = new JLabel("Agents");
		lblNewLabel_4_1.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setBounds(0, 2, 167, 25);
		panel_2_1.add(lblNewLabel_4_1);
		
		JPanel panel_2_1_1 = new JPanel();
		panel_2_1_1.setBackground(Color.WHITE);
		panel_2_1_1.setForeground(Color.GREEN);
		panel_2_1_1.setBounds(10, 295, 167, 30);
		panel.add(panel_2_1_1);
		panel_2_1_1.setLayout(null);
		
		JLabel lblNewLabel_4_2 = new JLabel("Selling");
		lblNewLabel_4_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				selling selling;
				hide();
				try {
					selling = new selling();
					selling.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		lblNewLabel_4_2.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2.setBounds(0, 2, 167, 25);
		panel_2_1_1.add(lblNewLabel_4_2);
		
		
		
		
		ImageIcon imageIcon11 = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(167, 122, Image.SCALE_DEFAULT));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(10, 11, 167, 122);
		lblNewLabel_3.setIcon(imageIcon11);
		lblNewLabel_3.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.white));
		panel.add(lblNewLabel_3);
		
		JPanel panel_2_1_2 = new JPanel();
		panel_2_1_2.setLayout(null);
		panel_2_1_2.setForeground(Color.GREEN);
		panel_2_1_2.setBackground(Color.WHITE);
		panel_2_1_2.setBounds(10, 253, 167, 30);
		panel.add(panel_2_1_2);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("Medicine");
		lblNewLabel_4_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				hide();
				try {
					medicine medicine=new medicine();
					medicine.visible();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		lblNewLabel_4_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1.setFont(new Font("Serif", Font.PLAIN, 15));
		lblNewLabel_4_1_1.setBounds(0, 2, 167, 25);
		panel_2_1_2.add(lblNewLabel_4_1_1);
		
		//panel_3.setIcon(imageIcon2);


		//frame.getContentPane().add(panel);
		frame.setBounds(100, 100, 755, 648);
		frame.setUndecorated(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	protected static void hide() {
		frame.hide();
	}
	public  void visible() {
		frame.setVisible(true);
		lblNewLabel_4_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_4_1.setForeground(Color.blue);
		lblNewLabel_4_1.setOpaque(true);
	}
}
