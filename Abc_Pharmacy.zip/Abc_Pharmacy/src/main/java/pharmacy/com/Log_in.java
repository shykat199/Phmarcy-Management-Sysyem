package pharmacy.com;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.RenderingHints;

import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class Log_in {

	private static JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Log_in window = new Log_in();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Log_in() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		
		
		ImageIcon imageIcon = new ImageIcon(new ImageIcon(
				"E:\\LPU\\All Semester\\2ND year\\Semester 2\\Java\\Java GUI\\Abc_Pharmacy\\pharmacy.jpg")
						.getImage().getScaledInstance(320, 150, Image.SCALE_DEFAULT));
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.GREEN);
		panel.setBounds(0, 0, 298, 362);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ABC Pharmachy");
		lblNewLabel.setFont(new Font("Stencil", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 86, 278, 38);
		panel.add(lblNewLabel);
		
		JLabel lblNearToYou = new JLabel("Near To You");
		lblNearToYou.setHorizontalAlignment(SwingConstants.CENTER);
		lblNearToYou.setForeground(Color.WHITE);
		lblNearToYou.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNearToYou.setBounds(10, 184, 278, 38);
		panel.add(lblNearToYou);
		
		JLabel lblCentralizedSystem = new JLabel("Centralized System");
		lblCentralizedSystem.setHorizontalAlignment(SwingConstants.CENTER);
		lblCentralizedSystem.setForeground(Color.WHITE);
		lblCentralizedSystem.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblCentralizedSystem.setBounds(10, 135, 278, 38);
		panel.add(lblCentralizedSystem);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(299, 0, 313, 362);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		

		JPanel x = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
			}
		};
		x.setBounds(256, 11, 47, 45);
		panel_1.add(x);
		x.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				System.exit(0);
			}
		});
		x.setBackground(Color.WHITE);
		x.setOpaque(false);
		x.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("X");
		lblNewLabel_1.setForeground(Color.green);
		lblNewLabel_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 22));
		lblNewLabel_1.setBounds(5, 11, 37, 23);
		x.add(lblNewLabel_1);
		
		JPanel x_1 = new JPanel() {
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Dimension arcs = new Dimension(400, 500);
				int width = getWidth();
				int height = getHeight();
				Graphics2D graphics = (Graphics2D) g;
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

				// Draws the rounded opaque panel with borders.
				graphics.setColor(getBackground());
				graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint background
				graphics.setColor(getForeground());
				graphics.drawRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);// paint border
			}
		};
		x_1.setBounds(206, 11, 47, 45);
		panel_1.add(x_1);
		x_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.setState(JFrame.ICONIFIED);
			}
		});
		x_1.setLayout(null);
		x_1.setOpaque(false);
		x_1.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_1_1 = new JLabel("-");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.green);
		lblNewLabel_1_1.setFont(new Font("SansSerif", Font.BOLD, 35));
		lblNewLabel_1_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1_1.setBounds(5, 7, 37, 23);
		x_1.add(lblNewLabel_1_1);
		
		JLabel lblLogIn = new JLabel("LOG IN");
		lblLogIn.setBackground(Color.WHITE);
		lblLogIn.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogIn.setForeground(Color.GREEN);
		lblLogIn.setFont(new Font("Serif", Font.BOLD, 30));
		lblLogIn.setBounds(10, 67, 293, 38);
		panel_1.add(lblLogIn);
		
		JLabel lblNewLabel_2 = new JLabel("User Id");
		lblNewLabel_2.setBackground(Color.WHITE);
		//lblNewLabel_2.setForeground(Color.green);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(10, 148, 72, 26);
		panel_1.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBackground(Color.WHITE);
		textField.setBounds(113, 148, 165, 26);
		panel_1.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2_1 = new JLabel("User Id");
		lblNewLabel_2_1.setForeground(Color.BLACK);
		lblNewLabel_2_1.setBackground(Color.WHITE);
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_1.setBounds(10, 209, 72, 26);
		panel_1.add(lblNewLabel_2_1);
		
		passwordField = new JPasswordField();
		passwordField.setBackground(Color.WHITE);
		passwordField.setBounds(113, 209, 165, 26);
		panel_1.add(passwordField);
		
		JSeparator separator = new JSeparator();
		separator.setBackground(Color.BLACK);
		separator.setForeground(Color.BLACK);
		separator.setBounds(97, 103, 117, 2);
		panel_1.add(separator);
		
		JButton btnNewButton = new JButton("LogIn");
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton.setBackground(Color.GREEN);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBounds(84, 271, 101, 31);
		panel_1.add(btnNewButton);
		
		JButton btnCancel = new JButton("Clear");
		btnCancel.setFont(new Font("Serif", Font.BOLD, 20));
		btnCancel.setForeground(Color.WHITE);
		btnCancel.setBackground(Color.GREEN);
		btnCancel.setBounds(189, 271, 101, 31);
		panel_1.add(btnCancel);

		//frame.getContentPane().add(panel);
		frame.setBounds(100, 100, 612, 362);
		frame.setUndecorated(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	protected static void hide() {
		frame.hide();
	}

	public void visible() {
		// TODO Auto-generated method stub
		frame.setVisible(true);
	}
}
